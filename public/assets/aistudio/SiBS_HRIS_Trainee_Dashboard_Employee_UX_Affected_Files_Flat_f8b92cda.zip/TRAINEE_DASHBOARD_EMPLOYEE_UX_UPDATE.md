# SiBS HRIS — Trainee Dashboard Employee-First UX Update

Base project: `remix-remix-sibs-hris (6).zip` (the user’s most recent uploaded project).

## Source files changed

- `src/components/journey/views/TraineeDashboardView.tsx` — employee-facing layout and accessibility improvements; does not change scores, training/attendance data persistence, staff authorizations or NHO handoffs.
- `scripts/test-trainee-calendar.ts` — extended to 53 calendar, ownership, and UX-specific assertions.
- `scripts/smoke-trainee-calendar.cjs` — updated to the new calendar label and role-aware UI checks.

## What's new

1. **My Training — Selected Day** appears immediately below the greeting; shows outstanding submissions, requested revisions, awaiting reviews and verified activities. Direct action opens the already-existing training submission dialog.
2. **Current published FST/PST scores** remain near the top, clearly distinguished from the selected historical date. Grades are unchanged. The passed/graded denominator and any unscored published assessments are explicitly identified.
3. **Week/Month calendar toggle.** Week is the low-friction default; Month retains the full monthly training calendar. On small viewports, the week view becomes a horizontal day strip and Month can be scrolled. The existing Day-90 boundaries remain enforced.
4. **Better empty states.** No assigned materials/goals shows **Not scheduled**, never 0% performance; the nearest later assigned day can be opened directly.
5. **Trainer attribution.** On dates without scheduled tasks, the app does not claim a daily trainer assignment; it separately names the general training contact. Task-specific trainers still take priority.
6. **My Progress & Attendance** follows daily tasks. The existing recorded-day attendance rate is now accompanied by expected-day coverage and a warning that missing time records are not absences. Submitted and Verified totals remain distinct.
7. **Clearer actions.** `Submitted` is displayed as **Awaiting trainer review**; `Revision requested` as **Needs revision**, with appropriately labeled buttons and inline status explanations. No workflow transition was changed.
8. **Staff-only control clarity.** The employee selection control is hidden for the Employee role, and labeled **Viewing employee** for authorized staff, while retaining the existing staff-preview capabilities.
9. All detailed FST and PST assessment records, full Employee Journey record, daily goals, materials, phase owner, feedback, staff activity creation, filters, and other existing content remain available.
10. Added accessible pressed states for Week/Month and task filters, dialog semantics, Escape-to-close, focus-visible styles, and explicit date labels.

## Verification performed in the extracted archive

- Workflow regression: **125/125 passed**.
- Authentication: **17/17 passed**.
- Trainer Coaching Impact: **18/18 passed**.
- Calendar and UX: **53/53 passed**.
- Calendar render smoke: **Employee, Trainer, and HR Admin passed**.
- Coaching render smoke: **4/4 passed**.
- NHO design consistency passed.
- TypeScript TS/TSX transpilation: **166 files; 0 syntax diagnostics**.

Not run: real Vite production build or full interactive browser/keyboard testing, because the exported project doesn't include installed runtime dependencies. Source smoke tests do not constitute a full visual/browser accessibility audit.

## Installing the flat affected-files ZIP

The flat ZIP intentionally contains no directories. Replace each **existing** file in its respective location (paths above). Do **not** create new `-1.tsx` copies in Google AI Studio. For a simpler import, use the full-project ZIP instead.

The project uses illustrative browser-local data and remains a prototype; no production database was changed.
