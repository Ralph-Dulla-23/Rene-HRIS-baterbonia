# SiBS HRIS — Trainee Dashboard Calendar & Trainer Scores Update

## Base and scope
- Updated the user's latest `remix-remix-sibs-hris (4).zip`, retaining NHO and Trainer Coaching Impact source code.
- Visual/function reference: `SiBS_HRIS_Trainee_Dashboard_Calendar_Trainer_Scores.html`.
- Browser-only Remix prototype; no production backend, user account, or live Kronos source is connected.

## What's included
1. **Monthly calendar** with Monday-first alignment, month arrows, disabled out-of-range dates, date picker, selected-day highlighting, demo-date marker, counts of materials/goals, attendance, and trainers.
2. **Four published FST/PST score summaries at the top**: overall graded average, FST, PST, and assessment pass count. Full per-assessment grades remain visible in a separate read-only section below daily tasks.
3. **Selected-day trainer/phase owner card** linked to the active calendar date. Explicit task-level trainer takes precedence; absent assignments fall back to the cohort trainer with clear messaging. The original assignment `owner` remains the creator/assigner, not a presumed trainer.
4. **Goal and material submissions** use the existing TrainingProgress submission/verification flow, with staff read-only in the trainee view and employee submission disabled for completed/submitted tasks or future dates.
5. **Authorized staff activity creation** in this prototype, with title, instructions, duration, priority and assigned trainer. HR Admin/Super Admin can create within the training period; Trainer can author for their own FST cohort; Team Leader/Manager for later phases. Creation is blocked for a closed Journey, past days, missing start date or dates beyond Day 90.
6. **Accuracy fixes**: missing attendance becomes N/A (not 100%); current/future attendance is not assumed; missing published grades show Not scored; no synthetic start date or trainer identity is created.

## Affected files and destination paths (for manual application)
- `TraineeDashboardView.tsx` -> `src/components/journey/views/TraineeDashboardView.tsx`
- `traineeCalendarUtils.ts` -> `src/components/journey/traineeCalendarUtils.ts` (new)
- `JourneyContext.tsx` -> `src/components/journey/JourneyContext.tsx`
- `journeyTypes.ts` -> `src/components/journey/journeyTypes.ts`
- `journeyInitialData.ts` -> `src/components/journey/journeyInitialData.ts`
- `test-trainee-calendar.ts` -> `scripts/test-trainee-calendar.ts` (new)
- `smoke-trainee-calendar.cjs` -> `scripts/smoke-trainee-calendar.cjs` (new)

**Important:** The *Affected Files — Flat ZIP* is intentionally flat (no source folders). Replace files at the destinations above. Do not create duplicate `-1.tsx` files in AI Studio; use the full project ZIP for consistent imports.

## Verification
- 125/125 prior workflow regression tests passed.
- 17/17 authentication tests passed.
- 18/18 trainer coaching assertions passed (temporary module-format compatibility adjustment in test runner; existing source was not modified).
- 35/35 new calendar/date/trainer/permission regression checks passed.
- 3/3 React-component render smoke checks passed (Employee/Trainer/HR Admin).
- 155 TS/TSX/JS source & script parse checks passed.
- Full Vite build and live browser visual QA were **not** performed: source ZIP had no `node_modules`; `tsc --noEmit` reports missing dependency/type declarations.

## Explicit constraints
- Dates are based on `startDate` first, with `hireDate` as existing fallback, **not** the scheduled NHO date. If neither is recorded, only the demo reference date is selectable.
- Task ownership is not the same as trainer identity; a fallback cohort trainer does **not** establish a confirmed shift roster.
- Calendar and coaching changes do not alter QA scoring, FST/PST grades, HR reviews, role-specific workflows, or NHO handoffs.
- This is a client-side demo; authorization checks in browser code are not production server-side enforcement.
