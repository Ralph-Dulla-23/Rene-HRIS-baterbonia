import { useDemoAuth } from "../../../auth/DemoAuthContext";
import React, { useState } from "react";
import type { TrainingAssignment } from "../journeyTypes";
import { addCalendarDays, trainingDateBounds, dateWithinBounds, clampTrainingDate, clampCalendarMonth, moveCalendarMonth, calendarMonthCells, trainerForTask, trainersForDay, phaseOwnerForDay, canCreateTrainingAssignment } from "../traineeCalendarUtils";
import { useJourney } from "../JourneyContext";
import { 
  BookOpen, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  FileText, 
  Award, 
  TrendingUp, 
  Calendar as CalendarIcon, 
  User, 
  Send, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Building2,
  Check,
  Sparkles,
  Layers,
  Eye,
  ChevronLeft,
  Filter,
  CheckCircle,
  HelpCircle,
  X
} from "lucide-react";

interface TraineeDashboardViewProps {
  onSwitchModule?: (moduleKey: string) => void;
}

export default function TraineeDashboardView({ onSwitchModule }: TraineeDashboardViewProps) {
  const {user} = useDemoAuth();
  const isEmployee = user?.role === 'Employee';
  const { 
    journeys, 
    assignments, 
    progress, 
    assessments, 
    assessmentGrades, 
    phaseTrainingScores, 
    attendance, 
    submitAssignment,
    addTrainingAssignment,
    verifyAssignment,
    simulatedCurrentDate,
    setSelectedJourney 
  } = useJourney();

  // Selected trainee for personal view
  const [selectedEmpId, setSelectedEmpId] = useState<string>(() => {
    return journeys[0]?.sibsEmployeeId || journeys[0]?.id || "SIBS-2901";
  });

  const [requestedTrainingDate, setTrainingDate] = useState<string>(simulatedCurrentDate || "2026-10-14");
  const [requestedCalendarMonth, setCalendarMonth] = useState<string | null>(null);
  const [isAddingAssignment, setIsAddingAssignment] = useState(false);
  const [newActivity, setNewActivity] = useState({ type: "Material" as "Material" | "Goal", title: "", details: "", duration: "20 min", priority: "Normal" as "Normal" | "High", trainer: "" });
  const [taskFilter, setTaskFilter] = useState<"All" | "To do" | "For review" | "Verified">("All");

  const [activeMaterialModal, setActiveMaterialModal] = useState<any | null>(null);
  const [submissionNote, setSubmissionNote] = useState("");
  const [showSuccessToast, setShowSuccessToast] = useState<string | null>(null);

  const ownJourney = isEmployee ? journeys.find(j => j.sibsEmployeeId === user?.journeyEmployeeId || j.id === user?.journeyEmployeeId || (user?.email && j.email?.toLowerCase() === user.email.toLowerCase())) : null;
  const currentJourney = isEmployee ? ownJourney : (journeys.find(j => j.sibsEmployeeId === selectedEmpId || j.id === selectedEmpId) || journeys[0]);
  if (!currentJourney) return <div className="p-6 rounded-xl bg-white border border-[#E6ECF2] text-slate-600">No Employee Journey is linked to your demo profile.</div>;
  const empKey = currentJourney.sibsEmployeeId || currentJourney.id;
  const journeyStartDate = currentJourney.startDate || currentJourney.hireDate;
  const dateBounds = trainingDateBounds(journeyStartDate, simulatedCurrentDate);
  const trainingDate = clampTrainingDate(requestedTrainingDate, dateBounds);
  const calendarMonth = clampCalendarMonth(requestedCalendarMonth || trainingDate.slice(0, 7), dateBounds);
  const monthCells = calendarMonthCells(calendarMonth);
  const pickTrainingDate = (date: string) => {
    if (!dateWithinBounds(date, dateBounds)) return;
    setTrainingDate(date);
    setCalendarMonth(date.slice(0, 7));
  };
  const changeMonth = (offset: number) => {
    const next = moveCalendarMonth(calendarMonth, offset);
    if (next >= dateBounds.min.slice(0, 7) && next <= dateBounds.max.slice(0, 7)) setCalendarMonth(next);
  };

  // Helper date functions
  const dayOffset = (dateStr: string, numDays: number) => {
    return addCalendarDays(dateStr, numDays);
  };

  const dateLabel = (dStr: string) => {
    if (!dStr) return "—";
    return new Date(dStr + "T12:00:00Z").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric", timeZone: "UTC" });
  };

  const weekOf = (dateStr: string) => {
    const d = new Date(dateStr + "T12:00:00Z");
    const mon = dayOffset(dateStr, -((d.getUTCDay() + 6) % 7));
    return Array.from({ length: 7 }, (_, i) => dayOffset(mon, i));
  };

  const getAttendanceAt = (dateStr: string) => {
    if (dateStr > simulatedCurrentDate) return "Upcoming";
    if (!journeyStartDate || dateStr < journeyStartDate) return "Not scheduled";
    const weekday = new Date(dateStr + "T12:00:00Z").getUTCDay();
    if (weekday === 0 || weekday === 6) return "Rest day";
    const match = attendance.find(a => (a.emp === empKey || a.emp === currentJourney.id) && a.date === dateStr);
    return match?.status || "Unrecorded";
  };

  const attendanceTone = (status: string) => {
    switch (status) {
      case "Present": return "sibs-tone-green-bg sibs-tone-green-text border sibs-tone-green-border";
      case "Late": return "sibs-tone-amber-bg sibs-tone-amber-text border sibs-tone-amber-border";
      case "Absent": return "sibs-tone-red-bg sibs-tone-red-text border sibs-tone-red-border";
      case "Excused": return "sibs-tone-blue-bg sibs-tone-blue-text border sibs-tone-blue-border";
      default: return "bg-[#F7F9FC] text-slate-600 border border-[#E6ECF2]";
    }
  };

  // Trainee assignments & materials
  const traineeAssignments = assignments.filter(a => a.emp === empKey || a.emp === currentJourney?.id);
  const selectedDayAssignments = traineeAssignments.filter(a => a.date === trainingDate);
  const dayTrainer = trainersForDay(selectedDayAssignments, currentJourney.trainerName);
  const phaseContact = phaseOwnerForDay(journeyStartDate, trainingDate, currentJourney.trainerName, currentJourney.tl);
  const canAddActivity = canCreateTrainingAssignment(user?.role, user?.trainerName, currentJourney.trainerName, trainingDate, dateBounds, simulatedCurrentDate, currentJourney.finalOutcome);
  const availableTrainers = Array.from(new Set(journeys.map(j => j.trainerName).filter((name): name is string => !!name)));
  const chooseTrainer = () => newActivity.trainer || (user?.role === "Trainer" ? user.trainerName || "" : currentJourney.trainerName || "");
  const materialRows = selectedDayAssignments.filter(a => a.type === "Material");
  const goalRows = selectedDayAssignments.filter(a => a.type === "Goal");

  const getSubmission = (item: any) => {
    return progress.find(p => (p.emp === empKey || p.emp === currentJourney.id) && p.assignmentId === item.id);
  };

  const getStatus = (item: any) => {
    return getSubmission(item)?.status || "Not started";
  };

  const getTone = (status: string) => {
    switch (status) {
      case "Verified": return "sibs-tone-green-bg sibs-tone-green-text border sibs-tone-green-border";
      case "Submitted": return "sibs-tone-blue-bg sibs-tone-blue-text border sibs-tone-blue-border";
      case "Revision requested": return "sibs-tone-red-bg sibs-tone-red-text border sibs-tone-red-border";
      case "In progress": return "sibs-tone-amber-bg sibs-tone-amber-text border sibs-tone-amber-border";
      default: return "bg-slate-100 text-slate-600 border border-slate-200";
    }
  };

  const filterMatches = (item: any) => {
    const st = getStatus(item);
    if (taskFilter === "All") return true;
    if (taskFilter === "To do") return ["Not started", "In progress", "Revision requested"].includes(st);
    if (taskFilter === "For review") return st === "Submitted";
    if (taskFilter === "Verified") return st === "Verified";
    return true;
  };

  // Weekly stats
  const weekDays = weekOf(trainingDate);
  const weekMaterials = weekDays.flatMap(day => traineeAssignments.filter(a => a.date === day && a.type === "Material"));
  const weekSubmitted = weekMaterials.filter(a => ["Submitted", "Verified"].includes(getStatus(a))).length;
  const weekVerified = weekMaterials.filter(a => getStatus(a) === "Verified").length;
  const weekRevision = weekMaterials.filter(a => getStatus(a) === "Revision requested").length;
  const weekPct = weekMaterials.length ? Math.round((100 * weekSubmitted) / weekMaterials.length) : 0;

  // Selected day stats
  const daySubmitted = materialRows.filter(a => ["Submitted", "Verified"].includes(getStatus(a))).length;
  const dayVerified = materialRows.filter(a => getStatus(a) === "Verified").length;
  const dayPct = materialRows.length ? Math.round((100 * daySubmitted) / materialRows.length) : 0;

  // Trainee 14-day attendance
  const traineeAttendance = attendance.filter(a => a.emp === empKey || a.emp === currentJourney?.id);
  const recent14Days = Array.from({ length: 14 }, (_, i) => dayOffset(simulatedCurrentDate, -i)).filter(dStr => {
    if (!journeyStartDate || dStr < journeyStartDate) return false;
    const w = new Date(dStr + "T12:00:00Z").getUTCDay();
    return w !== 0 && w !== 6;
  });
  let attPresent = 0, attLate = 0, attAbsent = 0, attExcused = 0, attMissing = 0;
  recent14Days.forEach(dStr => {
    const st = getAttendanceAt(dStr);
    if (st === "Present") attPresent++;
    else if (st === "Late") attLate++;
    else if (st === "Absent") attAbsent++;
    else if (st === "Excused") attExcused++;
    else attMissing++;
  });
  const attRecorded = attPresent + attLate + attAbsent + attExcused;
  const attRate = attRecorded ? Math.round(((attPresent + attLate) / attRecorded) * 100) : null;

  // Trainee FST & PST assessment grades
  const publishedAssessments = assessments.filter(a => a.status === "Published" && (a.account === "All accounts" || a.account === currentJourney.account));
  const traineeGrades = assessmentGrades.filter(g => g.emp === empKey || g.emp === currentJourney.id);
  const assessmentResults = publishedAssessments.map(a => {
    const grade = traineeGrades.find(g => g.assessmentId === a.id);
    const pct = grade ? Math.round((100 * grade.score) / a.max) : null;
    const passed = grade ? grade.score >= a.passing : false;
    return { a, grade, pct, passed };
  });

  const gradedItems = assessmentResults.filter(x => x.pct !== null);
  const passedItems = gradedItems.filter(x => x.passed);
  const overallAvg = gradedItems.length ? Math.round(gradedItems.reduce((acc, x) => acc + (x.pct || 0), 0) / gradedItems.length) : null;

  const fstItems = assessmentResults.filter(x => x.a.phase === "FST");
  const fstGraded = fstItems.filter(x => x.pct !== null);
  const fstAvg = fstGraded.length ? Math.round(fstGraded.reduce((acc, x) => acc + (x.pct || 0), 0) / fstGraded.length) : null;

  const pstItems = assessmentResults.filter(x => x.a.phase === "PST");
  const pstGraded = pstItems.filter(x => x.pct !== null);
  const pstAvg = pstGraded.length ? Math.round(pstGraded.reduce((acc, x) => acc + (x.pct || 0), 0) / pstGraded.length) : null;

  const upcomingMaterials = traineeAssignments.filter(a => a.type === "Material" && a.date > trainingDate).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 3);

  const handleCreateActivity = (e: React.FormEvent) => {
    e.preventDefault();
    const assignedTrainer = chooseTrainer();
    if (!canAddActivity || !newActivity.title.trim() || !newActivity.details.trim() || !newActivity.duration.trim() || !assignedTrainer || !availableTrainers.includes(assignedTrainer) || (user?.role === "Trainer" && assignedTrainer !== user.trainerName)) return;
    addTrainingAssignment({
      emp: empKey, date: trainingDate, type: newActivity.type, title: newActivity.title.trim(),
      description: newActivity.details.trim().slice(0, 145), details: newActivity.details.trim(),
      category: newActivity.type === "Material" ? "Learning" : "Practice",
      duration: newActivity.duration.trim(), priority: newActivity.priority,
      trainer: assignedTrainer, owner: user?.name || "Demo staff"
    });
    setNewActivity({ type: "Material", title: "", details: "", duration: "20 min", priority: "Normal", trainer: "" });
    setIsAddingAssignment(false);
    setShowSuccessToast("Training activity added to the selected day.");
    setTimeout(() => setShowSuccessToast(null), 3000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeMaterialModal || !isEmployee || !!currentJourney.finalOutcome || activeMaterialModal.date > simulatedCurrentDate || !["Not started", "In progress", "Revision requested"].includes(getStatus(activeMaterialModal))) return;
    submitAssignment(activeMaterialModal.id, empKey, submissionNote);
    setShowSuccessToast(`Submitted "${activeMaterialModal.title}" for trainer review!`);
    setActiveMaterialModal(null);
    setSubmissionNote("");
    setTimeout(() => setShowSuccessToast(null), 3000);
  };

  const selectedAttendance = getAttendanceAt(trainingDate);
  const isToday = trainingDate === simulatedCurrentDate;

  return (
    <div className="space-y-6">
      {/* SiBS HRIS Standard Header: White card with top accent gradient bar */}
      <section className="overflow-hidden rounded-xl border border-[#E6ECF2] bg-white shadow-xs">
        <div className="h-[3.5px] w-full bg-gradient-to-r from-[#042C51] via-[#c24b30] to-[#FF5C28]" />
        <div className="flex flex-wrap items-center justify-between gap-4 p-4 sm:p-5">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-blue-100 bg-[#E9F0FC] px-2.5 py-0.5 text-[9px] font-extrabold uppercase tracking-wide text-[#042C51]">
                <span className="h-1.5 w-1.5 rounded-full bg-[#FF5C28]" />
                Trainee Learning Portal • Day {currentJourney.daysElapsed} of 90
              </span>
              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[9.5px] font-bold ${attendanceTone(selectedAttendance)}`}>
                Attendance: {selectedAttendance}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-[#042C51]">
              Good to see you, {currentJourney.fullName.split(" ")[0]}!
            </h1>
            <p className="text-xs text-[#667085] max-w-3xl leading-normal">
              Track your daily learning materials, FST & PST module grades, daily goals, and trainer verification status.
            </p>
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] font-medium text-slate-500">
                <strong className="text-[#042C51]">Trainer:</strong> {currentJourney.trainerName || "Assigned Trainer"}
              </span>
              <span className="text-slate-300">•</span>
              <span className="text-[11px] font-medium text-slate-500">
                <strong className="text-[#042C51]">Account:</strong> {currentJourney.account}
              </span>
              <span className="text-slate-300">•</span>
              <span className="text-[11px] font-medium text-slate-500">
                <strong className="text-[#042C51]">Site:</strong> {currentJourney.siteLocation}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-2 bg-[#F7F9FC] border border-[#BECBDA] rounded-xl px-3 py-1.5">
              <span className="text-xs font-bold text-[#042C51] uppercase tracking-wider">Trainee Persona:</span>
              <select 
                disabled={isEmployee}
                value={isEmployee ? (currentJourney.sibsEmployeeId || currentJourney.id) : selectedEmpId}
                onChange={e => { setSelectedEmpId(e.target.value); setCalendarMonth(null); setTrainingDate(simulatedCurrentDate); }}
                className="text-xs font-semibold text-[#042C51] bg-transparent outline-none cursor-pointer"
              >
                {(isEmployee ? [currentJourney] : journeys).map(j => (
                  <option key={j.id} value={j.sibsEmployeeId || j.id}>
                    {j.fullName} ({j.sibsEmployeeId || j.kronosId || "No ID"})
                  </option>
                ))}
              </select>
            </div>

            <button
              type="button"
              onClick={() => setSelectedJourney(currentJourney)}
              className="text-xs font-semibold text-[#042C51] bg-white hover:bg-[#F7F9FC] border border-[#BECBDA] px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs"
            >
              <Eye className="w-3.5 h-3.5 text-[#FF5C28]" />
              <span>Open 7-Tab Record</span>
            </button>

            {!isEmployee && onSwitchModule && (
              <button
                type="button"
                onClick={() => onSwitchModule("New Hire Orientation (NHO)")}
                className="px-3.5 py-2 rounded-xl border border-[#BECBDA] hover:bg-[#F7F9FC] text-[#042C51] font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
              >
                <Layers className="w-4 h-4 text-[#FF5C28]" />
                <span>Back to NHO</span>
              </button>
            )}
          </div>
        </div>
      </section>

      {showSuccessToast && (
        <div className="sibs-tone-green-bg border sibs-tone-green-border sibs-tone-green-text text-xs px-4 py-2.5 rounded-xl flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            <span className="font-semibold">{showSuccessToast}</span>
          </div>
        </div>
      )}

      {/* Published FST/PST scores stay above the training calendar. Missing scores are not zero. */}
      <section className="rounded-xl border border-[#E6ECF2] bg-white p-4 sm:p-5 shadow-xs" aria-label="Published FST and PST score summary">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div><h2 className="text-sm font-extrabold text-[#042C51]">My Training Scores</h2><p className="text-xs text-slate-500 mt-1">Published trainer-entered assessments only · Read-only</p></div>
          <a href="#trainee-assessment-details" className="text-xs font-bold text-[#B54708] hover:underline">View detailed results ↓</a>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {[
            { label: "Overall graded average", value: overallAvg === null ? "Not scored" : `${overallAvg}%`, note: `${gradedItems.length} graded assessments`, color: "text-[#042C51]" },
            { label: "FST average", value: fstAvg === null ? "Not scored" : `${fstAvg}%`, note: `${fstGraded.length} scored FST items`, color: "text-blue-700" },
            { label: "PST average", value: pstAvg === null ? "Not scored" : `${pstAvg}%`, note: `${pstGraded.length} scored PST items`, color: "text-[#B54708]" },
            { label: "Assessments passed", value: `${passedItems.length} / ${gradedItems.length}`, note: "Graded and published only", color: "text-emerald-700" }
          ].map(metric => <div key={metric.label} className="rounded-xl border border-[#E6ECF2] bg-[#F7F9FC] p-3.5 min-w-0">
            <p className="text-[10px] uppercase tracking-wide font-extrabold text-slate-500">{metric.label}</p>
            <strong className={`block mt-2 text-lg sm:text-2xl font-black tabular-nums ${metric.color}`}>{metric.value}</strong>
            <p className="text-[10px] text-slate-500 mt-1">{metric.note}</p>
          </div>)}
        </div>
      </section>

      {/* Full month schedule: one selected day drives materials, goals, attendance and trainers. */}
      <section className="bg-white rounded-xl border border-[#E6ECF2] shadow-xs p-4 sm:p-5 space-y-4" aria-label="Monthly training calendar">
        <div className="flex flex-wrap justify-between items-center gap-3 border-b border-slate-100 pb-3">
          <div><h2 className="text-sm font-extrabold text-[#042C51]">Monthly Training Calendar</h2><p className="text-xs text-slate-500 mt-1">Select a day to view tasks, attendance and the responsible trainer.</p></div>
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={() => changeMonth(-1)} disabled={calendarMonth <= dateBounds.min.slice(0, 7)} aria-label="Previous calendar month" className="p-2 rounded-lg border border-[#BECBDA] hover:bg-[#F7F9FC] disabled:opacity-40 disabled:cursor-not-allowed"><ChevronLeft className="w-4 h-4"/></button>
            <span className="min-w-[130px] text-center text-sm font-extrabold text-[#042C51]">{new Date(`${calendarMonth}-01T12:00:00Z`).toLocaleDateString("en-US", {month:"long",year:"numeric",timeZone:"UTC"})}</span>
            <button type="button" onClick={() => changeMonth(1)} disabled={calendarMonth >= dateBounds.max.slice(0, 7)} aria-label="Next calendar month" className="p-2 rounded-lg border border-[#BECBDA] hover:bg-[#F7F9FC] disabled:opacity-40 disabled:cursor-not-allowed"><ChevronRight className="w-4 h-4"/></button>
            <label className="flex items-center gap-2 border border-[#BECBDA] rounded-lg px-2 py-1.5 text-xs text-slate-500">Date
              <input type="date" value={trainingDate} min={dateBounds.min} max={dateBounds.max} onChange={e => pickTrainingDate(e.target.value)} aria-label="Choose training date" className="bg-transparent text-xs font-semibold text-[#042C51] outline-none"/>
            </label>
            <button type="button" onClick={() => pickTrainingDate(clampTrainingDate(simulatedCurrentDate, dateBounds))} className="rounded-lg border border-[#BECBDA] px-3 py-2 text-xs font-bold text-[#042C51] hover:bg-[#F7F9FC]">Demo date</button>
          </div>
        </div>
        {!dateBounds.linked && <p className="text-xs rounded-lg p-3 bg-amber-50 text-amber-800 border border-amber-200">A confirmed employee start date is needed to display the full 90-day schedule. Only the demo date is available.</p>}
        <div className="grid grid-cols-7 gap-1 sm:gap-1.5" aria-hidden="true">{["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map(day => <span key={day} className="py-1 text-center text-[9px] sm:text-[10px] font-extrabold text-slate-500 uppercase">{day}</span>)}</div>
        <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
          {monthCells.map((date, index) => {
            if (!date) return <div key={`blank-${index}`} className="min-w-0" aria-hidden="true"/>;
            const within = dateWithinBounds(date, dateBounds);
            const dayItems = within ? traineeAssignments.filter(a => a.date === date) : [];
            const trainers = trainersForDay(dayItems, currentJourney.trainerName);
            const att = within ? getAttendanceAt(date) : "Outside training period";
            const mats = dayItems.filter(a => a.type === "Material").length;
            const goals = dayItems.filter(a => a.type === "Goal").length;
            const selected = date === trainingDate;
            return <button key={date} type="button" disabled={!within} onClick={() => pickTrainingDate(date)} aria-pressed={selected}
              aria-label={`${date}: ${mats} materials, ${goals} goals; ${att}; trainer ${trainers.names.join(" / ") || "not assigned"}`}
              className={`min-w-0 min-h-[77px] sm:min-h-[106px] rounded-lg border p-1 sm:p-2 text-left flex flex-col gap-1 transition-colors ${selected ? "bg-teal-50 border-2 border-teal-500" : within ? "bg-[#FBFDFF] border-[#E6ECF2] hover:bg-blue-50 hover:border-blue-300" : "bg-slate-50/60 border-dashed border-slate-200 opacity-50 cursor-not-allowed"}`}>
              <span className="text-xs sm:text-sm font-black text-[#042C51]">{Number(date.slice(-2))}{date === simulatedCurrentDate && <span className="text-orange-500"> ·</span>}</span>
              {within ? <>
                <span className="text-[9px] sm:text-[10px] leading-tight text-slate-600">{mats} material{mats===1?"":"s"} · {goals} goal{goals===1?"":"s"}</span>
                <span className="hidden sm:block text-[9px] text-[#215789] font-bold leading-tight break-words">{trainers.names.join(" / ") || "Trainer not assigned"}</span>
                <span className={`self-start rounded-md px-1 text-[8px] sm:text-[9px] font-bold ${attendanceTone(att)}`}>{att === "Unrecorded" ? "Pending record" : att}</span>
              </> : <span className="text-[9px] text-slate-400">—</span>}
            </button>;
          })}
        </div>
        <p className="text-[10px] text-slate-500">Orange dot: demo date · Teal border: selected day · Attendance is based on recorded sample shifts, never inferred from missing punches.</p>
      </section>

      {/* Trainer assignment can differ by task; staff owner and trainer are separate roles. */}
      <section className="rounded-xl border border-teal-100 bg-[#F1FAFC] p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4" aria-label="Selected-day trainers and phase owner">
        <div className="flex gap-3 items-center min-w-0">
          <div className="h-10 w-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0"><User className="w-5 h-5"/></div>
          <div className="min-w-0"><p className="text-[10px] font-extrabold uppercase text-slate-500">Assigned trainer{dayTrainer.names.length === 1 ? "" : "s"} · {dateLabel(trainingDate)}</p>
            <h3 className="text-base font-black text-[#042C51] mt-1">{dayTrainer.names.join(" / ") || "Trainer not assigned"}</h3>
            <p className="text-xs text-slate-500 mt-1">{selectedDayAssignments.length} scheduled tasks · {dayTrainer.explicit ? "Trainer recorded for each task" : "Cohort trainer shown as fallback where individual assignments are missing"}</p>
          </div>
        </div>
        <div className="bg-white border border-[#DCE8EF] rounded-lg px-3 py-2 text-xs text-slate-600"><span className="block">Phase owner / support contact</span><strong className="block text-[#042C51] mt-1">{phaseContact.owner || "Not assigned"}</strong><span className="text-[10px]">{phaseContact.phase}</span></div>
      </section>

      {canAddActivity && <div className="flex justify-end"><button type="button" onClick={() => setIsAddingAssignment(true)} className="px-4 py-2.5 bg-[#FF5C28] text-white font-bold text-xs rounded-xl hover:bg-orange-600">+ Assign training activity</button></div>}

      {/* 3 Compact SiBS HRIS Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
        {/* Metric 1: Selected Day Materials */}
        <div className="flex min-h-[86px] sm:min-h-[92px] flex-col justify-between rounded-xl border border-[#E6ECF2] bg-white p-3 sm:p-3.5 shadow-xs transition-all hover:shadow-sm">
          <div className="flex items-center justify-between gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-700 truncate">
              Day Materials ({trainingDate})
            </span>
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-blue-100 bg-blue-50 text-blue-600">
              <BookOpen className="h-3.5 w-3.5" />
            </div>
          </div>
          <div className="mt-1">
            <div className="flex items-baseline justify-between">
              <div className="text-xl sm:text-2xl font-black tabular-nums tracking-tight text-[#042C51]">
                {daySubmitted} <span className="text-sm font-semibold text-slate-400">/ {materialRows.length}</span>
              </div>
              <span className="text-xs font-bold text-[#FF5C28]">{dayPct}%</span>
            </div>
            <div className="w-full h-1.5 bg-[#E6EAF0] rounded-full overflow-hidden mt-1.5">
              <div className="h-full bg-[#FF5C28] rounded-full" style={{ width: `${dayPct}%` }} />
            </div>
            <div className="mt-1 flex items-center justify-between text-[10.5px] font-medium text-slate-500">
              <span>{dayVerified} verified by trainer</span>
              <span>{materialRows.length - daySubmitted} pending</span>
            </div>
          </div>
        </div>

        {/* Metric 2: Weekly Progress */}
        <div className="flex min-h-[86px] sm:min-h-[92px] flex-col justify-between rounded-xl border border-[#E6ECF2] bg-white p-3 sm:p-3.5 shadow-xs transition-all hover:shadow-sm">
          <div className="flex items-center justify-between gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-wider text-blue-700 truncate">
              Weekly Progress (7-Day)
            </span>
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-blue-100 bg-blue-50 text-blue-600">
              <TrendingUp className="h-3.5 w-3.5" />
            </div>
          </div>
          <div className="mt-1">
            <div className="flex items-baseline justify-between">
              <div className="text-xl sm:text-2xl font-black tabular-nums tracking-tight text-[#042C51]">
                {weekSubmitted} <span className="text-sm font-semibold text-slate-400">/ {weekMaterials.length}</span>
              </div>
              <span className="text-xs font-bold text-[#042C51]">{weekPct}%</span>
            </div>
            <div className="w-full h-1.5 bg-[#E6EAF0] rounded-full overflow-hidden mt-1.5">
              <div className="h-full bg-[#042C51] rounded-full" style={{ width: `${weekPct}%` }} />
            </div>
            <div className="mt-1 flex items-center justify-between text-[10.5px] font-medium text-slate-500">
              <span>{weekVerified} verified</span>
              {weekRevision > 0 ? (
                <span className="text-[#E74C3C] font-bold">{weekRevision} revision needed</span>
              ) : (
                <span>0 revisions</span>
              )}
            </div>
          </div>
        </div>

        {/* Metric 3: Attendance Summary */}
        <div className="flex min-h-[86px] sm:min-h-[92px] flex-col justify-between rounded-xl border border-[#E6ECF2] bg-white p-3 sm:p-3.5 shadow-xs transition-all hover:shadow-sm">
          <div className="flex items-center justify-between gap-1.5">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-700 truncate">
              14-Day Attendance
            </span>
            <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-emerald-100 bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="h-3.5 w-3.5" />
            </div>
          </div>
          <div className="mt-1">
            <div className="flex items-baseline justify-between">
              <div className="text-xl sm:text-2xl font-black tabular-nums tracking-tight text-[#042C51]">
                {attPresent + attLate} <span className="text-xs font-medium text-slate-400">/ {attRecorded} recorded days</span>
              </div>
              <span className="text-xs font-bold text-emerald-600">{attRate === null ? "N/A" : `${attRate}%`}</span>
            </div>
            <div className="w-full h-1.5 bg-[#E6EAF0] rounded-full overflow-hidden mt-1.5">
              <div className="h-full bg-[#2ECC71] rounded-full" style={{ width: `${attRate ?? 0}%` }} />
            </div>
            <div className="mt-1 flex items-center justify-between text-[10.5px] font-medium text-slate-500">
              <span>{attLate} late • {attAbsent} absent</span>
              <span>{attExcused} excused · {attMissing} unrecorded</span>
            </div>
          </div>
        </div>
      </div>

      {/* One daily view for materials and goals. Published assessment details stay below. */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="min-w-0 space-y-5">
          <div className="bg-white rounded-2xl border border-[#E6ECF2] shadow-xs p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-sm font-extrabold text-[#042C51]">Assigned Learning Materials ({trainingDate})</h2>
                <p className="text-xs text-slate-500">Read materials, complete tasks, and submit for trainer verification.</p>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center gap-1 bg-[#F7F9FC] border border-[#BECBDA] p-1 rounded-xl">
                {(["All", "To do", "For review", "Verified"] as const).map(f => (
                  <button
                    key={f}
                    onClick={() => setTaskFilter(f)}
                    className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                      taskFilter === f ? "bg-white text-[#042C51] shadow-xs" : "text-slate-500 hover:text-[#042C51]"
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            {/* Itemized Materials Table / List */}
            {materialRows.filter(filterMatches).length === 0 ? (
              <div className="py-10 text-center text-slate-400 space-y-2">
                <BookOpen className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-semibold">No materials found for {trainingDate} matching filter "{taskFilter}".</p>
                <p className="text-[11px] text-slate-400">Select another day on the calendar above.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {materialRows.filter(filterMatches).map(item => {
                  const sub = getSubmission(item);
                  const st = getStatus(item);

                  return (
                    <div 
                      key={item.id} 
                      className="p-4 rounded-xl border border-[#E6ECF2] bg-white hover:border-[#BECBDA] transition-all shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{item.category || "General"}</span>
                          <span className={`px-2 py-0.2 rounded text-[10px] font-bold ${getTone(st)}`}>
                            {st}
                          </span>
                          {item.priority === "High" && (
                            <span className="px-2 py-0.2 rounded text-[10px] font-bold sibs-tone-amber-bg sibs-tone-amber-text border sibs-tone-amber-border">
                              High Priority
                            </span>
                          )}
                        </div>

                        <h3 className="text-sm font-extrabold text-[#042C51]">{item.title}</h3>
                        <p className="text-xs text-slate-500">{item.description}</p>
                        
                        <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-1">
                          <span>Trainer: {trainerForTask(item, currentJourney.trainerName) || "Not assigned"}</span><span>•</span><span>Assigned by: {item.owner || "Not recorded"}</span>
                          <span>•</span>
                          <span>Duration: {item.duration}</span>
                        </div>

                        {sub?.feedback && (
                          <div className="mt-2 p-2.5 rounded-lg sibs-tone-blue-bg border sibs-tone-blue-border text-xs text-[#042C51]">
                            <strong className="block text-[10px] uppercase font-bold text-[#215789]">Trainer Feedback:</strong>
                            <p className="mt-0.5">{sub.feedback}</p>
                          </div>
                        )}
                      </div>

                      <div className="shrink-0 flex items-center gap-2">
                        <button
                          onClick={() => { setSubmissionNote(getSubmission(item)?.note || ""); setActiveMaterialModal(item); }}
                          className={`px-3.5 py-1.5 rounded-xl font-semibold text-xs transition-colors cursor-pointer shadow-xs ${
                            st === "Verified" 
                              ? "bg-white border border-[#BECBDA] text-[#042C51] hover:bg-[#F7F9FC]" 
                              : "bg-[#FF5C28] hover:bg-[#e04f20] text-white"
                          }`}
                        >
                          {st === "Verified" ? "View Material" : st === "Submitted" ? "View Submission" : !isEmployee ? "View Details" : "Open & Submit"}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>
        {/* Today’s training goals use the existing submit/review data model. */}
        <section className="min-w-0 rounded-xl border border-[#E6ECF2] bg-white shadow-xs p-4 sm:p-5 space-y-4">
          <div><h2 className="text-sm font-extrabold text-[#042C51]">Training Goals ({trainingDate})</h2><p className="text-xs text-slate-500 mt-1">Complete practice exercises and submit progress for trainer verification.</p></div>
          {goalRows.filter(filterMatches).length === 0 ? <p className="text-xs text-slate-500 bg-slate-50 border border-slate-200 rounded-lg p-5">No training goals for this day matching “{taskFilter}”.</p> :
            goalRows.filter(filterMatches).map(goal => {
              const st = getStatus(goal);
              const feedback = getSubmission(goal)?.feedback;
              return <article key={goal.id} className="p-4 rounded-xl border border-[#E6ECF2] bg-[#FAFCFF] space-y-2">
                <div className="flex justify-between gap-2 items-start"><strong className="text-sm text-[#042C51]">{goal.title}</strong><span className={`shrink-0 px-2 py-0.5 rounded text-[10px] font-bold ${getTone(st)}`}>{st}</span></div>
                <p className="text-xs text-slate-500">{goal.description}</p>
                <div className="text-[10px] text-slate-500">Trainer: <strong className="text-[#042C51]">{trainerForTask(goal, currentJourney.trainerName) || "Not assigned"}</strong> · Assigned by {goal.owner || "Not recorded"} · {goal.duration}</div>
                {feedback && <p className="text-xs bg-blue-50 border border-blue-100 p-2 rounded-lg text-blue-900">Trainer feedback: {feedback}</p>}
                <button type="button" onClick={() => { setSubmissionNote(getSubmission(goal)?.note || ""); setActiveMaterialModal(goal); }} className="px-3 py-2 rounded-lg border border-[#BECBDA] text-xs font-bold text-[#042C51] bg-white hover:bg-[#F7F9FC]">{st === "Verified" || st === "Submitted" ? "View Goal & Submission" : isEmployee ? "Open & Submit Progress" : "View Goal"}</button>
              </article>;
            })}
        </section>
      </div>

      {/* Complete scorecards remain accessible without crowding the daily tasks. */}
      <section id="trainee-assessment-details" className="bg-white rounded-xl border border-[#E6ECF2] shadow-xs p-4 sm:p-5 space-y-4 scroll-mt-24">
        <div className="flex flex-wrap items-center justify-between gap-2"><div><h2 className="text-sm font-extrabold text-[#042C51]">Detailed FST & PST Assessment Results</h2><p className="text-xs text-slate-500 mt-1">Published grades entered by authorized assessors. These are separate from independent QA and coaching evidence.</p></div><span className="text-[10px] font-bold text-slate-400 uppercase">Read-only</span></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[{label:"FST · Days 1–14",avg:fstAvg},{label:"PST · Days 15–28",avg:pstAvg}].map(({label,avg})=><div key={label} className="bg-[#F7F9FC] border border-[#E6ECF2] rounded-xl p-3">
            <div className="flex justify-between items-center gap-2 text-xs"><strong>{label}</strong><span className="font-bold">{avg === null ? "Not scored" : `${avg}%`}</span></div>
            <div className="h-1.5 rounded-full bg-slate-200 overflow-hidden mt-2"><div className="h-full bg-[#FF5C28]" style={{width:`${avg ?? 0}%`}}/></div>
          </div>)}
        </div>
        {assessmentResults.length === 0 ? <p className="rounded-lg p-4 bg-slate-50 text-xs text-slate-500">No published FST/PST assessments for this account.</p> :
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">{assessmentResults.map(({ a, grade, pct, passed }) => (
            <article key={a.id} className="border border-[#E6ECF2] rounded-xl p-3.5 space-y-1.5">
              <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-[10px] uppercase font-bold text-slate-500">{a.phase} · {a.skill}</span><span className={`text-[10px] px-2 py-0.5 rounded font-bold ${pct === null ? "bg-slate-100 text-slate-600" : passed ? "sibs-tone-green-bg sibs-tone-green-text" : "sibs-tone-red-bg sibs-tone-red-text"}`}>{pct === null ? "Not scored" : passed ? "Passed" : "Below target"}</span></div>
              <strong className="text-xs block text-[#042C51]">{a.title}</strong>
              <div className="flex justify-between gap-2 text-xs text-slate-500"><span>Score: {grade ? grade.score : "—"} / {a.max}</span><span>Passing: {a.passing}</span></div>
              {grade && <p className="text-[10px] text-slate-500">Graded by {grade.grader} · {dateLabel(grade.date)}</p>}
            </article>
          ))}</div>}
      </section>

      {/* Authorized staff can assign an individual trainer to each activity. */}
      {isAddingAssignment && canAddActivity && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) setIsAddingAssignment(false); }}>
          <form onSubmit={handleCreateActivity} className="bg-white rounded-xl shadow-xl w-full max-w-lg p-5 space-y-3 max-h-[90vh] overflow-y-auto" aria-label="Assign training activity">
            <div className="flex items-center justify-between"><h3 className="font-black text-[#042C51]">New Training Activity · {dateLabel(trainingDate)}</h3><button type="button" aria-label="Close assignment form" onClick={() => setIsAddingAssignment(false)}><X className="w-5 h-5"/></button></div>
            <label className="block text-xs font-bold">Type<select value={newActivity.type} onChange={e => setNewActivity(p=>({...p,type:e.target.value as "Goal"|"Material"}))} className="block w-full border rounded-lg p-2 mt-1"><option>Material</option><option>Goal</option></select></label>
            <label className="block text-xs font-bold">Title<input required maxLength={140} value={newActivity.title} onChange={e=>setNewActivity(p=>({...p,title:e.target.value}))} className="block w-full border rounded-lg p-2 mt-1"/></label>
            <label className="block text-xs font-bold">Learning instructions / success criteria<textarea required rows={4} value={newActivity.details} onChange={e=>setNewActivity(p=>({...p,details:e.target.value}))} className="block w-full border rounded-lg p-2 mt-1"/></label>
            <label className="block text-xs font-bold">Assigned trainer<select required value={chooseTrainer()} onChange={e=>setNewActivity(p=>({...p,trainer:e.target.value}))} className="block w-full border rounded-lg p-2 mt-1">
              {availableTrainers.filter(name=>user?.role !== "Trainer" || name===user.trainerName).map(name=><option key={name} value={name}>{name}</option>)}
            </select></label>
            <div className="grid grid-cols-2 gap-3"><label className="block text-xs font-bold">Duration<input value={newActivity.duration} required onChange={e=>setNewActivity(p=>({...p,duration:e.target.value}))} className="block w-full border rounded-lg p-2 mt-1"/></label><label className="block text-xs font-bold">Priority<select value={newActivity.priority} onChange={e=>setNewActivity(p=>({...p,priority:e.target.value as "Normal"|"High"}))} className="block w-full border rounded-lg p-2 mt-1"><option>Normal</option><option>High</option></select></label></div>
            <p className="text-[11px] text-slate-500">Prototype records are saved in browser storage. A task's creator is separate from its assigned trainer.</p>
            <div className="flex justify-end gap-2"><button type="button" onClick={()=>setIsAddingAssignment(false)} className="border rounded-lg px-4 py-2 text-xs font-bold">Cancel</button><button type="submit" className="bg-[#FF5C28] text-white rounded-lg px-4 py-2 text-xs font-bold">Save activity</button></div>
          </form>
        </div>
      )}

      {/* Material Detail & Submission Modal */}
      {activeMaterialModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-xl border border-[#E6ECF2]">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">{activeMaterialModal.category} • {activeMaterialModal.duration}</span>
                <h3 className="text-base font-extrabold text-[#042C51]">{activeMaterialModal.title}</h3>
              </div>
              <button onClick={() => setActiveMaterialModal(null)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">{activeMaterialModal.description}</p>
            <div className="p-3 rounded-xl bg-[#F7F9FC] border border-[#E6ECF2] text-xs space-y-1">
              <strong className="text-[#042C51] block">Instructions:</strong>
              <p className="text-slate-600">{activeMaterialModal.details || "Review guidelines, practice required steps, and upload or enter your completion notes below."}</p>
            </div>

            <p className="text-xs text-[#61788F]">Assigned trainer: {trainerForTask(activeMaterialModal, currentJourney.trainerName) || "Not assigned"} · Assigned by: {activeMaterialModal.owner || "Not recorded"}</p>
            {getSubmission(activeMaterialModal)?.feedback && <p className="text-xs bg-blue-50 p-2 rounded-lg">Reviewer feedback: {getSubmission(activeMaterialModal)?.feedback}</p>}
            {isEmployee && !currentJourney.finalOutcome && activeMaterialModal.date <= simulatedCurrentDate && ["Not started", "In progress", "Revision requested"].includes(getStatus(activeMaterialModal)) ? <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-[#042C51] mb-1">Completion Notes / Submission Link</label>
                <textarea 
                  rows={3}
                  value={submissionNote}
                  onChange={e => setSubmissionNote(e.target.value)}
                  placeholder="Enter completion details, work simulation links, or questions for your trainer..."
                  className="w-full p-2.5 rounded-xl border border-[#BECBDA] text-xs outline-none focus:border-[#FF5C28]"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveMaterialModal(null)}
                  className="px-4 py-2 rounded-xl border border-[#BECBDA] text-[#042C51] font-semibold text-xs hover:bg-[#F7F9FC]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#FF5C28] hover:bg-[#e04f20] text-white font-semibold text-xs shadow-xs"
                >
                  Submit to Trainer
                </button>
              </div>
            </form> : <div className="space-y-3"><p className="text-xs text-slate-500">{getSubmission(activeMaterialModal)?.note ? `Submission: ${getSubmission(activeMaterialModal)?.note}` : "No submission recorded."}</p><div className="flex justify-end"><button type="button" onClick={() => setActiveMaterialModal(null)} className="px-4 py-2 rounded-lg border text-xs font-bold">Close</button></div></div>}
          </div>
        </div>
      )}
    </div>
  );
}
