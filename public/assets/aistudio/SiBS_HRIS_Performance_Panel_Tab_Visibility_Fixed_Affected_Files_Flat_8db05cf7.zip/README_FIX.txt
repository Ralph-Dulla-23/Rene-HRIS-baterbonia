SiBS HRIS — Employee Journey Drilldown Tab Visibility Fix

Affected file (flat ZIP):
EmployeeJourneyDrillDown.tsx

Replace existing:
src/components/journey/drilldown/EmployeeJourneyDrillDown.tsx

Fix:
The Training & Milestone Performance panel now renders only when the Journey Timeline tab is active. Other tabs start with their own relevant content.

No scoring, workflow, data, or permissions were altered.

Validation: TSX syntax parsed; 125 workflow tests, 17 authentication tests, 18 coaching checks, 40 calendar checks, and NHO design consistency checks passed. Browser visual testing not performed.
